module.exports = {
    theme: {
        extend: {},
        colors: {
            primary: "#ffffff",
            dark: "#0e0e10",
            darkFont: "rgb(239, 239, 241)",
        },
    },
    variants: {},
    plugins: [],
};
