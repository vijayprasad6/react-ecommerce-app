import Foter from "./Foter";

export default Foter;
