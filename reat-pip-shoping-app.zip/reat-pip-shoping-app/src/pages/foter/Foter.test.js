import React from "react";
import { render } from "@testing-library/react";
import Store from "../../app/Store";
import Foter from "./Foter";

describe("<Foter />", () => {
    test("Should have add button", () => {
        const { getByText } = render(
            <Store>
                <Foter />
            </Store>
        );

        expect(getByText(/Add/i)).toBeInTheDocument();
    });
});
