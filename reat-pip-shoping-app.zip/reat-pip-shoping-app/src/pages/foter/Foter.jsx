import React from "react";

// import useCount from "../../hooks/useCount";
// import useTheme from "../../hooks/useTheme";
//import logo from "../../logo.svg";

export default function Foter() {
    return (
        <footer className="py-lg-5 py-3">
            <div className="container-fluid px-lg-5 px-3">
                <div className="copyright-w3layouts mt-4">
                    <p className="copy-right text-center ">
                        &copy; 2020 My Shopping. All Rights Reserved | Design by
                        Vijay Prasad
                    </p>
                </div>
            </div>
        </footer>
    );
}
