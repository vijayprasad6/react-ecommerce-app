import React from "react";
import ProdcutCard from "./productCard";
import productsData from "./productsData";

export default function Products() {
    //const countProd = productsData.length;
    const productComponents = productsData.map((prod) => (
        <ProdcutCard key={prod.id} prodDetail={prod} />
    ));
    return (
        <div className="container-fluid">
            <div className="inner-sec-shop px-lg-4 px-3">
                <h3 className="tittle-w3layouts my-lg-4 my-4">
                    New Arrivals for you...{/*countProd*/}
                </h3>
                <div className="row">
                    {productComponents}
                    <div></div>
                </div>
            </div>
        </div>
    );
}
