import React, { Component } from "react";

class ProdcutCard extends Component {
    state = {
        id: this.props.prodDetail.id,
        title: this.props.prodDetail.title,
        type: this.props.prodDetail.type,
        price: this.props.prodDetail.price,
        short_description: this.props.prodDetail.short_description,
        full_description: this.props.prodDetail.full_description,
        filename: this.props.prodDetail.filename,
        width: this.props.prodDetail.width,
        height: this.props.prodDetail.height,
    };

    render() {
        //console.log(this.props);
        const imgpath = "images/" + this.state.filename;
        const prodDetailPagePath =
            "/productDetails/" + this.props.prodDetail.id;
        return (
            <React.Fragment>
                <div className="col-md-3 product-men women_two">
                    <div className="product-googles-info googles">
                        <div className="men-pro-item">
                            <div className="men-thumb-item">
                                <img
                                    src={imgpath}
                                    className="img-fluid"
                                    alt=""
                                />
                                <div className="men-cart-pro">
                                    <div className="inner-men-cart-pro">
                                        <a
                                            href={prodDetailPagePath}
                                            className="link-product-add-cart"
                                        >
                                            Quick View
                                        </a>
                                    </div>
                                </div>
                                <span className="product-new-top">New</span>
                            </div>
                            <div className="item-info-product">
                                <div className="info-product-price">
                                    <div className="grid_meta">
                                        <div className="product_price">
                                            <h4>
                                                <a href="single.html">
                                                    {this.state.title}
                                                </a>
                                            </h4>
                                            <div className="grid-price mt-2">
                                                <span className="money">
                                                    ${this.state.price}
                                                </span>
                                            </div>
                                            <div className="grid-price mt-2">
                                                <a href="/#">
                                                    {
                                                        this.state
                                                            .short_description
                                                    }
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="googles single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <input
                                                type="hidden"
                                                name="cmd"
                                                value="_cart"
                                            />
                                            <input
                                                type="hidden"
                                                name="add"
                                                value="1"
                                            />
                                            <input
                                                type="hidden"
                                                name="googles_item"
                                                value="Opium (Grey)"
                                            />
                                            <input
                                                type="hidden"
                                                name="amount"
                                                value="325.00"
                                            />
                                            <button
                                                type="submit"
                                                className="googles-cart pgoogles-cart"
                                            >
                                                <i className="fas fa-cart-plus"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <div className="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*lineBreak*/}
            </React.Fragment>
        );
    }
}

export default ProdcutCard;
