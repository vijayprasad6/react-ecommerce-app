import React, { Component } from "react";

class TableHead extends Component {
    state = {
        tableHead: this.props.tablehead,
    };
    render() {
        return <th> {this.state.tableHead} </th>;
    }
}

export default TableHead;
