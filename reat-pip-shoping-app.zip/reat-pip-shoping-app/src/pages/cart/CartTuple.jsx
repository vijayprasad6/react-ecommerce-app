import React, { Component } from "react";

class CartTuple extends Component {
    constructor(props) {
        super(props);
        this.state = {
            googles_item: this.props.cartItems.googles_item,
            ProdId: this.props.cartItems.ProdId,
            cartItemTotalPrice: this.props.cartItems.prodTotalPrice,
            prodItemPrice: this.props.cartItems.prodItemPrice,
            prodImageName: this.props.cartItems.prodImageName,
            prodDiscount: this.props.cartItems.prodDiscount,
            prodTotalQuantity: this.props.cartItems.prodTotalQuantity,
            prodHref: this.props.cartItems.prodHref,
            prodItemIdx: this.props.cartItems.item_number_idx,
            categoryType: this.props.cartItems.categoryType,
            prodTitle: this.props.cartItems.prodTitle,
        };
    }

    increaseProduct = (e) => {
        let prodObjdata = {
            ProductImage: this.state.prodImageName,
            add: 1,
            amount: this.state.prodItemPrice,
            cmd: "_cart",
            discount: this.state.prodDiscount,
            googles_item: this.state.googles_item,
            href: this.state.prodHref,
            productId: this.state.ProdId,
            quantity: 1,
            categoryType: this.state.categoryType,
            prodTitle: this.state.prodTitle,
            showPopup: -1,
        };
        window.googles.cart.add(prodObjdata);
        window.location.reload();
    };

    decreaseProduct = () => {
        let prodObjdata = {
            ProductImage: this.state.prodImageName,
            add: 1,
            amount: this.state.prodItemPrice,
            cmd: "_cart",
            discount: this.state.prodDiscount,
            googles_item: this.state.googles_item,
            href: this.state.prodHref,
            productId: this.state.ProdId,
            quantity: -1,
            categoryType: this.state.categoryType,
            prodTitle: this.state.prodTitle,
            showPopup: -1,
        };
        window.googles.cart.add(prodObjdata);
        window.location.reload();
    };

    removeProduct = () => {
        window.googles.cart.remove(this.state.prodItemIdx);
        window.location.reload();
    };
    render() {
        let prodimagepath = "../images/" + this.state.prodImageName;
        let prodDetailspath = "/productDetails/" + this.state.ProdId;
        return (
            <tr className="rem1">
                <td className="invert">{this.state.prodItemIdx + 1}</td>
                <td className="invert-image">
                    <a href={prodDetailspath}>
                        <img
                            src={prodimagepath}
                            alt=" "
                            className="img-responsive"
                        />
                    </a>
                </td>
                <td className="invert">
                    <div className="quantity">
                        <div className="quantity-select">
                            <button
                                className="entry value-minus"
                                onClick={this.decreaseProduct}
                            >
                                &nbsp;
                            </button>
                            <div className="entry value">
                                <span>{this.state.prodTotalQuantity}</span>
                            </div>
                            <button
                                className="entry value-plus active"
                                onClick={this.increaseProduct}
                            >
                                &nbsp;
                            </button>
                        </div>
                    </div>
                </td>
                <td className="invert">
                    {this.state.prodTitle} <br />
                    <h5>Type: {this.state.categoryType} </h5>
                </td>
                <td className="invert">
                    {Number.parseFloat(this.state.cartItemTotalPrice).toFixed(
                        2
                    )}
                </td>
                <td className="invert">
                    <div className="rem">
                        <button
                            className="close1"
                            onClick={this.removeProduct}
                        ></button>
                    </div>
                </td>
            </tr>
        );
    }
}

export default CartTuple;
