import React, { Component } from "react";
import CartTuple from "./CartTuple";
import TableHead from "./TableHead";
class Cart extends Component {
    state = {};
    render() {
        let Checkoutcart = window.googles.cart;
        const totalCartLength = Checkoutcart.items().length;
        let checkoutItems = Checkoutcart.items();
        let totalCartvalue = 0;
        let totalCartDiscount = 0;
        let idx = 0;
        let wholeCartItem = checkoutItems.map((k) => {
            totalCartvalue += k._data.quantity * k._amount;
            totalCartDiscount = totalCartDiscount + k._data.discount;
            let tupleItems = {
                googles_item: k._data.googles_item,
                ProdId: k._data.productId,
                prodTotalPrice: k._data.quantity * k._amount,
                prodItemPrice: k._amount,
                prodImageName: k._data.ProductImage,
                prodDiscount: k._data._discount,
                prodTotalQuantity: k._data.quantity,
                prodHref: k._data.href,
                item_number_idx: idx,
                categoryType: k._data.categoryType,
                prodTitle: k._data.ptitle,
            };
            idx = idx + 1;
            return <CartTuple cartItems={tupleItems} key={k._data.productId} />;
        });

        const tableHeadRow = [
            "SL No.",
            "Product",
            "Quantity",
            "Product Name",
            "Price",
            "Remove",
        ];

        let tableHeadElement = tableHeadRow.map((item) => {
            return <TableHead tablehead={item} key={item} />;
        });
        return (
            <section className="banner-bottom-wthreelayouts py-lg-5 py-3">
                <div className="container">
                    <div className="inner-sec-shop px-lg-4 px-3">
                        <h3 className="tittle-w3layouts my-lg-4 mt-3">
                            Cart Details{" "}
                        </h3>
                        <div className="checkout-right">
                            <h4>
                                Your shopping cart contains:
                                <span>{totalCartLength} Products</span>
                            </h4>
                            <table className="timetable_sub">
                                <thead>
                                    <tr>{tableHeadElement}</tr>
                                </thead>
                                <tbody>
                                    {totalCartLength > 0 ? (
                                        wholeCartItem
                                    ) : (
                                        <tr>
                                            <td colSpan={6}>
                                                <h3
                                                    style={{
                                                        paddingLeft: "100px",
                                                        paddingTop: "30px",
                                                        paddingBottom: "30px",
                                                        fontWeight: "bold",
                                                    }}
                                                >
                                                    Your shopping cart is empty.
                                                </h3>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                            <div
                                style={{
                                    float: "right",
                                    paddingRight: "150px",
                                }}
                            >
                                <p
                                    style={{
                                        float: "right",
                                        paddingLeft: "300px",
                                        paddingTop: "30px",
                                        paddingBottom: "30px",
                                        fontWeight: "bold",
                                    }}
                                >
                                    <a href="/products" className="nav-link">
                                        Click here to continue shopping
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div
                    style={{
                        float: "left",
                        paddingLeft: "60px",
                        paddingTop: "40px",
                        fontWeight: "bold",
                    }}
                >
                    Product Total: ${" "}
                    {Number.parseFloat(totalCartvalue).toFixed(2)}
                </div>
                <div className="clearfix"> </div>
                <div style={{ float: "right", paddingRight: "60px" }}>
                    <button className="place_order">Place Order</button>
                </div>
            </section>
        );
    }
}

export default Cart;
