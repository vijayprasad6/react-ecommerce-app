import React, { Component } from "react";

class HiddenInputField extends Component {
    state = {
        name: this.props.name,
        fieldValue: this.props.fieldValue,
    };
    render() {
        console.log("test" + this.props.fieldValue);
        return (
            <input
                type="hidden"
                name={this.state.name}
                value={this.state.fieldValue}
            />
        );
    }
}

export default HiddenInputField;
