import React, { Component } from "react";
import productsData from "../products/productsData";
import ProductTitlePrice from "./ProductTitlePrice";
import UnOrderList from "./UnOrderList";
import ProductDetailDescTab1 from "./ProductDetailDescTab1";
//import ProdCategoryTypes from "./ProdCategoryTypes";
import ShareOnProdDetails from "./ShareOnProdDetails";
import OptionInputs from "./OptionInputs";
//import HiddenInputField from "./HiddenInputField";
import CustomerReview from "./CustomerReview";

class ProductDetails extends Component {
    constructor() {
        super();
        this.state = {
            quantity: 1,
            selectedCatTypeValue: "Irayz Butterfly(Black)",
        };
        this.handleChange = this.handleChange.bind(this);
        this.updatePrice = this.updatePrice.bind(this);
        this.updatePrice = this.updatePrice.bind(this);
    }

    handleChange(e) {
        var value = e.target.value;
        this.setState({
            quantity: value,
        });
    }

    updatePrice = (e) => {
        // const prodState = { ...this.state };
        var value = e.target.value;
        let obj = {
            selectedCatTypeValue: value,
        };

        this.setState(obj);
    };

    render() {
        // const productID = this.props.match.params.id;
        let prodDetail = productsData.filter(
            (prod) => prod.id == this.props.match.params.id
        );
        let prodImage = "../images/" + prodDetail[0].filename;
        const discountPercentage = 50;
        let prodDiscount = (prodDetail[0].price * discountPercentage) / 100;
        let prodPriceAfterDiscount = prodDetail[0].price - prodDiscount;
        let isSelected = null;
        const optionLists = [
            { id: 1, qtval: "1 Qty" },
            { id: 2, qtval: "2 Qty" },
            { id: 3, qtval: "3 Qty" },
            { id: 4, qtval: "4 Qty" },
            { id: 5, qtval: "5 Qty" },
            { id: 6, qtval: "6 Qty" },
            { id: 7, qtval: "7 Qty" },
            { id: 8, qtval: "8 Qty" },
            { id: 9, qtval: "9 Qty" },
            { id: 10, qtval: "10 Qty" },
        ];

        const optionList = optionLists.map((optObj) => {
            isSelected = this.state.quantity === optObj.id ? true : false;
            return (
                <OptionInputs
                    optid={optObj.id}
                    optvalue={optObj.qtval}
                    key={optObj.id}
                />
            );
        });

        let prodTitleCategory =
            prodDetail[0].title + " , Type: " + this.state.selectedCatTypeValue;
        return (
            <div className="container">
                <div className="inner-sec-shop pt-lg-4 pt-3">
                    <div className="row">
                        <div className="col-lg-5 single-right-left ">
                            <div className="grid images_3_of_2">
                                <div className="flexslider1">
                                    <ul className="slides">
                                        <li data-thumb={prodImage}>
                                            <div className="thumb-image">
                                                <img
                                                    src={prodImage}
                                                    data-imagezoom="true"
                                                    className="img-fluid"
                                                    alt=" "
                                                />
                                            </div>
                                        </li>
                                    </ul>
                                    <div className="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-7 single-right-left simpleCart_shelfItem">
                            <ProductTitlePrice
                                title={prodDetail[0].title}
                                originalPrice={prodDetail[0].price}
                                prodPriceAfterDiscount={prodPriceAfterDiscount}
                            />
                            <div className="color-quality">
                                <div className="color-quality-right">
                                    <label>Add Quantity :</label> &nbsp;
                                    <select
                                        id="quantity"
                                        className="frm-field required sect"
                                        name="quantity"
                                        onChange={this.handleChange}
                                        defaultValue={isSelected}
                                    >
                                        {optionList}
                                    </select>
                                </div>
                            </div>
                            <div className="occasional">
                                <h5>Types :</h5>
                                <div className="colr ert">
                                    <label className="radio">
                                        <input
                                            type="radio"
                                            name="category"
                                            value={prodDetail[0].catType[0]}
                                            checked={
                                                this.state
                                                    .selectedCatTypeValue ===
                                                prodDetail[0].catType[0]
                                            }
                                            onChange={this.updatePrice}
                                        />
                                        <i></i> {prodDetail[0].catType[0]}
                                    </label>
                                </div>
                                <div className="colr">
                                    <label className="radio">
                                        <input
                                            type="radio"
                                            name="category"
                                            value={prodDetail[0].catType[1]}
                                            checked={
                                                this.state
                                                    .selectedCatTypeValue ===
                                                prodDetail[0].catType[1]
                                            }
                                            onChange={this.updatePrice}
                                        />
                                        <i></i> {prodDetail[0].catType[1]}
                                    </label>
                                </div>
                                <div className="colr">
                                    <label className="radio">
                                        <input
                                            type="radio"
                                            name="category"
                                            value={prodDetail[0].catType[2]}
                                            checked={
                                                this.state
                                                    .selectedCatTypeValue ===
                                                prodDetail[0].catType[2]
                                            }
                                            onChange={this.updatePrice}
                                        />
                                        <i></i> {prodDetail[0].catType[2]}
                                    </label>
                                </div>
                                <div className="clearfix"> </div>
                            </div>
                            <div className="occasion-cart">
                                <div className="googles single-item singlepage">
                                    <form action="#" method="post">
                                        {/* {console.log(this.state.quantity)}
                                        {hiddenCartFields}
                                        {console.log(this.state.quantity)} */}
                                        <input
                                            type="hidden"
                                            name="cmd"
                                            value="_cart"
                                        />
                                        <input
                                            type="hidden"
                                            name="add"
                                            value="1"
                                        />
                                        <input
                                            type="hidden"
                                            name="googles_item"
                                            value={prodTitleCategory}
                                        />
                                        <input
                                            type="hidden"
                                            name="ptitle"
                                            value={prodDetail[0].title}
                                        />
                                        <input
                                            type="hidden"
                                            name="quantity"
                                            value={this.state.quantity}
                                        />
                                        <input
                                            type="hidden"
                                            name="categoryType"
                                            value={
                                                this.state.selectedCatTypeValue
                                            }
                                        />
                                        <input
                                            type="hidden"
                                            name="discount"
                                            value={prodDiscount}
                                        />
                                        <input
                                            type="hidden"
                                            name="productId"
                                            value={prodDetail[0].id}
                                        />
                                        <input
                                            type="hidden"
                                            name="amount"
                                            value={prodPriceAfterDiscount}
                                        />
                                        <input
                                            type="hidden"
                                            name="ProductImage"
                                            value={prodDetail[0].filename}
                                        />
                                        <input
                                            type="hidden"
                                            name="showPopup"
                                            value={1}
                                        />

                                        <button
                                            type="submit"
                                            className="googles-cart pgoogles-cart"
                                            style={{ width: "160px" }}
                                        >
                                            Add to Cart
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <p>&nbsp;</p>
                            <ShareOnProdDetails />
                        </div>
                        <div className="clearfix"> </div>
                        <div className="responsive_tabs">
                            <div id="horizontalTab">
                                <UnOrderList
                                    ULClassname={"resp-tabs-list"}
                                    LiClassName={""}
                                    liValue={["Description", "Customer Review"]}
                                />
                                <div className="resp-tabs-container">
                                    <div className="tab1">
                                        <div className="single_page">
                                            <ProductDetailDescTab1
                                                shortDesc={
                                                    prodDetail[0]
                                                        .short_description
                                                }
                                                fullDesc={
                                                    prodDetail[0]
                                                        .full_description
                                                }
                                            />
                                        </div>
                                    </div>
                                    <div className="tab2">
                                        <CustomerReview
                                            feedback={
                                                prodDetail[0].customerReview
                                            }
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ProductDetails;
