import React, { Component } from "react";

class CustomerReview extends Component {
    state = {
        customerReview: this.props.feedback ? this.props.feedback : null,
    };
    render() {
        return (
            <React.Fragment>
                <h6>Customer Review</h6>

                <p className="para">{this.state.customerReview}</p>
            </React.Fragment>
        );
    }
}

export default CustomerReview;
