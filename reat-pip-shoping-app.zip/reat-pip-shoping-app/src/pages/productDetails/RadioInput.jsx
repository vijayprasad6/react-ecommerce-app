import React, { Component } from "react";

class RadioInput extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isChecked: false,
            name: "prodCategory",
            classNm: this.props.classNm ? this.props.classNm : null,
            value: this.props.ckvalue,
            radioLable: this.props.radiolabel,
        };
    }
    render() {
        return (
            <div className="colr ert">
                <label className="radio">
                    <input
                        type="radio"
                        name={this.state.name}
                        value={this.state.value}
                        className={this.state.classNm}
                        onChange={this.props.handleRadioChange}
                    />
                    <i></i> {this.state.radioLable}
                </label>
            </div>
        );
    }
}

export default RadioInput;
