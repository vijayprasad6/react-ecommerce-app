import React, { Component } from "react";

class ProductDetailDescTab1 extends Component {
    state = {
        shortDesc: this.props.shortDesc ? this.props.shortDesc : null,
        fullDesc: this.props.fullDesc ? this.props.fullDesc : null,
    };
    render() {
        return (
            <React.Fragment>
                <h6>{this.state.shortDesc}</h6>

                <p className="para">
                    {this.state.fullDesc}
                    {/* Lorem ipsum dolor sit amet, consectetur adipisicing
                    elPellentesque vehicula augue eget nisl ullamcorper,
                    molestie blandit ipsum auctor. Mauris volutpat augue
                    dolor.Consectetur adipisicing elit, sed do eiusmod tempor
                    incididunt ut lab ore et dolore magna aliqua. Ut enim ad
                    minim veniam, quis nostrud exercitation ullamco. labore et
                    dolore magna aliqua. */}
                </p>
            </React.Fragment>
        );
    }
}

export default ProductDetailDescTab1;
