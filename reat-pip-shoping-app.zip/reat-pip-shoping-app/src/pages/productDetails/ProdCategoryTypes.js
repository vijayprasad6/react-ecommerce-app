import React, { Component } from "react";
import RadioInput from "./RadioInput";

class ProdCategoryTypes extends Component {
    state = {
        prodCatNm: this.props.prodCategory,
        prodCatTypes: this.props.ProdCatTypes,
    };
    render() {
        let prodCatType = "";
        const catTypeArr = prodCatType.map((item, key) => item);

        return (
            <div className="occasional">
                <h5>Types :</h5>
                <RadioInput
                    name={this.state.prodCatNm}
                    value={1}
                    classNm={this.state.prodCatNm}
                    radioLable={catTypeArr[0]}
                />
                <RadioInput
                    name={this.state.prodCatNm}
                    value={1}
                    classNm={this.state.prodCatNm}
                    radioLable={catTypeArr[1]}
                />
                <RadioInput
                    name={this.state.prodCatNm}
                    value={2}
                    classNm={this.state.prodCatNm}
                    radioLable={catTypeArr[2]}
                />
                <div className="clearfix"> </div>
            </div>
        );
    }
}

export default ProdCategoryTypes;
