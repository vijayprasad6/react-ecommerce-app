import React, { Component } from "react";
/* This componenet is created for sharing to Product inforation on social media */
class ShareOnProdDetails extends Component {
    state = {};
    render() {
        return (
            <div>
                <div style={{ float: "right" }}>
                    <a href="/products" className="nav-link">
                        Click Here to See More Products
                    </a>
                </div>
                <ul className="footer-social text-left mt-lg-4 mt-3">
                    <li>Share On : </li>
                    <li className="mx-2">
                        <a href="/#">
                            <span className="fab fa-facebook-f"></span>
                        </a>
                    </li>
                    <li className="mx-2">
                        <a href="/#">
                            <span className="fab fa-twitter"></span>
                        </a>
                    </li>
                    <li className="mx-2">
                        <a href="/#">
                            <span className="fab fa-google-plus-g"></span>
                        </a>
                    </li>
                    <li className="mx-2">
                        <a href="/#">
                            <span className="fab fa-linkedin-in"></span>
                        </a>
                    </li>
                    <li className="mx-2">
                        <a href="/#">
                            <span className="fas fa-rss"></span>
                        </a>
                    </li>
                </ul>
            </div>
        );
    }
}

export default ShareOnProdDetails;
