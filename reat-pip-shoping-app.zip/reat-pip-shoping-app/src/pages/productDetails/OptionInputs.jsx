import React, { Component } from "react";

class OptionInputs extends Component {
    state = {
        optid: this.props.optid,
        optvalue: this.props.optvalue,
        // isSelected: this.props.isSelected ? this.props.isSelected : 1,
    };
    render() {
        //let selected = this.state.isSelected;
        //console.log(this.state.optid);
        return <option value={this.state.optid}>{this.state.optvalue}</option>;
    }
}

export default OptionInputs;
