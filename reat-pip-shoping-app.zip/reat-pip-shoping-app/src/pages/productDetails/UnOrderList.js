import React, { Component } from "react";

class UnOrderList extends Component {
    state = {
        ULClassname: this.props.ULClassname ? this.props.ULClassname : null,
        LiClassName: this.props.LiClassName ? this.props.LiClassName : null,
        LiValue: this.props.liValue ? this.props.liValue : null,
    };
    render() {
        let liListvalue = this.state.LiValue.map((item) => {
            return (
                <li className={this.state.LiClassName} key={item.toString()}>
                    {item}
                </li>
            );
        });
        return <ul className={this.state.ULClassname}>{liListvalue}</ul>;
    }
}

export default UnOrderList;
