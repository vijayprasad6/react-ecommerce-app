import React, { Component } from "react";
class ProductTitlePrice extends Component {
    state = {
        prodOriginalPrice: this.props.originalPrice
            ? this.props.originalPrice
            : null,
        prodPriceAfterDiscount: this.props.prodPriceAfterDiscount
            ? this.props.prodPriceAfterDiscount
            : 0,
    };

    render() {
        return (
            <React.Fragment>
                <h3>{this.props.title}</h3>
                <p>
                    <label className="item_price">
                        Offer Price: ${this.state.prodPriceAfterDiscount}
                    </label>

                    <del style={{ fontWeight: `bold` }}>
                        <br />{" "}
                        <label className="item_price">
                            Origin Price: &nbsp;
                        </label>
                        ${this.state.prodOriginalPrice}
                    </del>
                </p>
            </React.Fragment>
        );
    }
}

export default ProductTitlePrice;
