import React from "react";
//import ProdcutCard from "../products/productCard";
//import productsData from "../products/productsData";

export default function Home() {
    return (
        <div className="container-fluid">
            <div className="inner-sec-shop px-lg-4 px-3">
                <h3 className="tittle-w3layouts my-lg-4 my-4">
                    This is home Page and yet to be implement.
                </h3>
            </div>
        </div>
    );
}
