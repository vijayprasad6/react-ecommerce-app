import React from "react";

function Logo() {
    return (
        <div className="col-md-3 top-info text-left">
            <h6>
                <img
                    src="../images/optic-shop-logo.JFIF"
                    alt="logo"
                    width="100"
                    height="60"
                />
            </h6>
            {/* <ul>
            <li>
              <i class="fas fa-phone"></i> Call Me </li>
            <li class="number-phone mt-3">+918582870466</li>
          </ul>*/}
        </div>
    );
}

export default Logo;
