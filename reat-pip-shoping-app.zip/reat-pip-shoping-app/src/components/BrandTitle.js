import React from "react";

function BrandTitle() {
    return (
        <div className="col-md-6 logo-w3layouts text-center">
            <h1 className="logo-w3layouts">
                <a className="navbar-brand" href="/#">
                    Optics Shopping App
                </a>
            </h1>
        </div>
    );
}
export default BrandTitle;
