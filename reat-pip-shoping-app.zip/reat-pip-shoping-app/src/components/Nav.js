import React from "react";
import { matchPath } from "react-router";

function Nav() {
    const navstyle = {
        width: "100%",
    };

    return (
        <React.Fragment>
            <nav
                className="avbar navbar-expand-lg navbar-light bg-light top-header mb-2"
                style={navstyle}
            >
                <button
                    className="navbar-toggler mx-auto"
                    type="button"
                    data-toggle="collapse"
                    data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div
                    className="collapse navbar-collapse"
                    id="navbarSupportedContent"
                >
                    <ul className="navbar-nav nav-mega mx-auto">
                        <li
                            className={
                                matchPath(window.location.pathname, {
                                    path: "/home",
                                })
                                    ? "nav-item active"
                                    : ""
                            }
                        >
                            <a className="nav-link ml-lg-0" href="/home">
                                Home
                                <span className="sr-only">(current)</span>
                            </a>
                        </li>
                        <li
                            className={
                                matchPath(window.location.pathname, {
                                    path: "/products",
                                })
                                    ? "nav-item active"
                                    : ""
                            }
                        >
                            <a className="nav-link" href="/products">
                                Products List
                            </a>
                        </li>
                        <li
                            className={
                                matchPath(window.location.pathname, {
                                    path: "/cart",
                                })
                                    ? "nav-item active"
                                    : ""
                            }
                        >
                            <a className="nav-link" href="/cart">
                                Cart
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </React.Fragment>
    );
}

export default Nav;
