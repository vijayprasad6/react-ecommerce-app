import React, { Component } from "react";

class Breadcrumb extends Component {
    render() {
        let currPathArr = window.location.pathname;
        let currPathArr1 = currPathArr.slice(1, currPathArr.length);
        // console.log(currPathArr1);
        currPathArr1 = currPathArr1 === "index.html" ? null : currPathArr1;
        return (
            <div className="banner_inner">
                <div className="services-breadcrumb">
                    <div className="inner_breadcrumb">
                        <ul className="short">
                            <li>
                                <a href="/home">Home</a>
                                <i>|</i>
                            </li>
                            <li>{currPathArr1} </li>
                        </ul>
                    </div>
                </div>
            </div>
        );
    }
}

export default Breadcrumb;
