import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "../pages/home";
import Products from "../pages/products";
import ProductDetails from "../pages/productDetails";
//import Checkout from "../pages/checkout/Checkout";
import Cart from "../pages/cart/Cart";

export default function MainContent() {
    return (
        <Router>
            <Switch>
                <Route exact path="/" component={Home} />
                <Route exact path="/home" component={Home} />
                <Route exact path="/products" component={Products} />
                <Route path="/productDetails/:id" component={ProductDetails} />
                {/* <Route path="/checkout" component={Checkout} /> */}
                <Route path="/cart" component={Cart} />
            </Switch>
        </Router>
    );
}
