import React from "react";
import Logo from "./Logo";
import BrandTitle from "./BrandTitle";
//import CartPage from "./CartPage";
import Nav from "./Nav";
import Breadcrumb from "./Breadcrumb";

function Header() {
    return (
        <div className="banner-top container-fluid" id="home">
            <header>
                <div className="row">
                    <Logo />
                    <BrandTitle />

                    <label className="top-log mx-auto"></label>
                    <Nav />
                </div>
            </header>
            <Breadcrumb />
        </div>
    );
}
export default Header;
