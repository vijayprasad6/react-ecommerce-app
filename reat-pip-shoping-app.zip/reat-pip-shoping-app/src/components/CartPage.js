import React from "react";

function CartPage() {
    return (
        <div className="col-md-3 top-info-cart text-right mt-lg-4">
            <ul className="cart-inner-info">
                <li className="galssescart galssescart2 cart cart box_1">
                    <form action="#" method="post" className="last">
                        <input type="hidden" name="cmd" value="_cart" />
                        <input type="hidden" name="display" value="1" />
                        <button
                            className="top_googles_cart"
                            type="submit"
                            name="submit"
                            value=""
                        >
                            Cart
                            <i className="fas fa-cart-arrow-down"></i>
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    );
}
export default CartPage;
