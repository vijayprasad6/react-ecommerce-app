import counterReducer from "./counter/reducer";

export default {
    counter: counterReducer,
};
