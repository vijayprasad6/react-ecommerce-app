import React from "react";
import Foter from "./pages/foter";
import Header from "./components/Header";
import MainContent from "./components/MainContent";
import "./App.css";

function App() {
    return (
        <React.Fragment>
            <Header />
            <MainContent />
            <br></br>
            <Foter />
        </React.Fragment>
    );
}

export default App;
